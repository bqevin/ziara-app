<?php
session_start();
include('travel_db_connect.php');
?>
<!DOCTYPE html>
<html>
<head>
<title> Ziara</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<style>
p,p2{background-color:white;opacity:0.9;color:blue;}
</style>
</head>
<body style="background-image:url(car.jpg);background-repeat:repeat;"link="lime"alink="lime"vlink="lime"/>
<div id="para"align="center">
<?php
$email = $_SESSION['email'];
$getimage = "SELECT * FROM info WHERE email = '$email'";
$result = mysql_query($getimage,$link);
?>
<div id="para"align="center">

<table bgcolor="dark-yellow"style="width:750px;">
<tr>
<td style="width:30px;">
<?php
while($row=mysql_fetch_array($result))
{
echo'<img src="data:image;base64,'.$row['image'].'" style="border-radius:50%50%50%50%;width:90px;height:90px;" ><br>';
}
?></td>

<td style="width:80px;"><a href="country.php">Home</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="Profile.php">Profile</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="Posts.php">Posts</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="Messages.php">Messages</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="Friends.php">Friends</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="Notifications.php">Notifications</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="your_campaigns.php">Campaigns</a></td><td style="width:10px;"></td>
<td style="width:80px;"><a href="your_events.php">Events</a><td style="width:10px;">
</td></tr></table>
<table style="width:750px;"bgcolor="white">
<tr>
<td >
<h1 style="color:orange;">Contact Us</h1>
<p><font color="blue">If you would wish to contact us please fill in the form below and send us a message.We can't reply to all messages but we promise to attend to your request.</font></p></td></tr></table>
<table bgcolor="white"style="width:750px;">
<tr>
<td align="left">
<?php
if(isset($_GET['msg']))
{
 $message = $_GET['msg'];
 if($message==1)
 {
   echo"<span style='background-color:green;color:red;'>Your message has been sent successfully.</span>";
 }
}
?>
<form method="post"action="contact_process.php">
<font color="FF0099">Subject:</font><br><input type="text"name="subject"placeholder="subject"><br>
<font color="FF0099">Message:</font><br><textarea rows="5"cols="40"name="message"placeholder="message"maxlength='400'></textarea><br>
<input type="submit"value="send"style="background-color:cyan;color:red;border-radius:8px;"></form>
<p><font color="orange">For quicker reply email us at:</font><font color="red"><i>(kelvinkagia@gmail.com) or at (digitarttechnologies@gmail.com).</i></font></p>
</td></tr></table>
